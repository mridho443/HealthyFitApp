List<Map<String, dynamic>> feelingDatas = [
  {
    "id": 1,
    "kategori": "Keagamaan",
  },
  {
    "id": 2,
    "kategori": "Sekolah",
  },
  {
    "id": 3,
    "kategori": "Sosial",
  },
  {
    "id": 4,
    "kategori": "Politik",
  },
  {
    "id": 5,
    "kategori": "Keuangan",
  },
  {
    "id": 6,
    "kategori": "Lingkungan",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
  {
    "id": 7,
    "kategori": "Lainnya",
  },
];
